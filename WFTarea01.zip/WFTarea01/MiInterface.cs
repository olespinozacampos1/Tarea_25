﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WFTarea01
{
    enum TipoNivel
    { 
        Estable =1,
        Invitado =2
    }

    enum TipoEstado
    {
        Directivo = 1, Administrativo = 2 , Asistente = 3
    }


    // Interface no lleva codigo
    interface MiInterface
    {
        string Nombres { set; get; }
        string ApePaterno { set; get; }
        string ApeMaterno { set; get; }
        DateTime FecNacimiento { set; get; }
        DateTime FecIngreso { set; get; }

        float CalcularEdad();
        float CalcularTiempoServicio();
        float CalcularBonificacion();
    }

    //clase padre
    class Colaborador : MiInterface
    {
        // declaracion de variables de instancia
        private string nombres;
        private string apePaterno;
        private string apeMaterno;
        private DateTime fecNacimiento;
        private DateTime fecIngreso;

        //propiedades
        public string Nombres { get => nombres; set => nombres = value; }
        public string ApePaterno { get => apePaterno; set => apePaterno=value; }
        public string ApeMaterno { get => apeMaterno; set => apeMaterno=value; }
        public DateTime FecNacimiento { get => fecNacimiento ; set => fecNacimiento = value; }
        public DateTime FecIngreso { get => fecIngreso; set => fecIngreso = value; }

        public float CalcularBonificacion()
        {
            throw new NotImplementedException();
        }

        public float CalcularEdad()
        {
            DateTime fechaActual = System.DateTime.Now;
            return fechaActual.Millisecond - FecNacimiento.Millisecond;
        }

        public float CalcularTiempoServicio()
        {
            DateTime fechaActual = System.DateTime.Now;
            return fechaActual.Millisecond - FecIngreso.Millisecond;
        }
    }

    class Instructor : Colaborador
    {
        public TipoNivel Nivel {set;get;}

        public new float CalcularBonificacion()
        {
            float bonificacion = 0;

            if (Nivel == TipoNivel.Estable)
                bonificacion = CalcularTiempoServicio() * 200;
            else  
                bonificacion = CalcularTiempoServicio() * 120;

            return bonificacion;
        }

    }

    class Empleado : Colaborador 
    {
        public TipoEstado Estado { set; get; }

        public new float CalcularBonificacion()
        {
            float bonificacion = 0;

            if (Estado == TipoEstado.Directivo)
                bonificacion = CalcularTiempoServicio() * 250;
            else if (Estado == TipoEstado.Administrativo)
                bonificacion = CalcularTiempoServicio() * 180;
            else
                bonificacion = CalcularTiempoServicio() * 100;

            return bonificacion;
        }

    }


}

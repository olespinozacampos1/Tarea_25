﻿
namespace WFTarea01
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cbColaborador = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rbEstable = new System.Windows.Forms.RadioButton();
            this.rbInvitado = new System.Windows.Forms.RadioButton();
            this.rbDirectivo = new System.Windows.Forms.RadioButton();
            this.rbAdminitrativo = new System.Windows.Forms.RadioButton();
            this.rbAsistente = new System.Windows.Forms.RadioButton();
            this.btnEdad = new System.Windows.Forms.Button();
            this.btnBoni = new System.Windows.Forms.Button();
            this.btnTServ = new System.Windows.Forms.Button();
            this.lblEdad = new System.Windows.Forms.Label();
            this.lblBoni = new System.Windows.Forms.Label();
            this.lblTServ = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nombres";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(30, 43);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(242, 20);
            this.textBox1.TabIndex = 1;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(30, 87);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(242, 20);
            this.textBox2.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(27, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Apellido Paterno";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(30, 130);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(242, 20);
            this.textBox3.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(27, 113);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Apellido Materno";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(30, 174);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(242, 20);
            this.textBox4.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(27, 157);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Fecha de Nacimiento";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(30, 218);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(242, 20);
            this.textBox5.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(27, 201);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Fecha de Ingreso";
            // 
            // cbColaborador
            // 
            this.cbColaborador.FormattingEnabled = true;
            this.cbColaborador.Items.AddRange(new object[] {
            "Instructor",
            "Empleado"});
            this.cbColaborador.Location = new System.Drawing.Point(30, 260);
            this.cbColaborador.Name = "cbColaborador";
            this.cbColaborador.Size = new System.Drawing.Size(242, 21);
            this.cbColaborador.TabIndex = 10;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbInvitado);
            this.groupBox1.Controls.Add(this.rbEstable);
            this.groupBox1.Location = new System.Drawing.Point(32, 312);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(103, 109);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Nivel";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rbAsistente);
            this.groupBox2.Controls.Add(this.rbAdminitrativo);
            this.groupBox2.Controls.Add(this.rbDirectivo);
            this.groupBox2.Location = new System.Drawing.Point(145, 312);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(127, 109);
            this.groupBox2.TabIndex = 12;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Estado";
            // 
            // rbEstable
            // 
            this.rbEstable.AutoSize = true;
            this.rbEstable.Location = new System.Drawing.Point(7, 20);
            this.rbEstable.Name = "rbEstable";
            this.rbEstable.Size = new System.Drawing.Size(60, 17);
            this.rbEstable.TabIndex = 0;
            this.rbEstable.TabStop = true;
            this.rbEstable.Text = "Estable";
            this.rbEstable.UseVisualStyleBackColor = true;
            // 
            // rbInvitado
            // 
            this.rbInvitado.AutoSize = true;
            this.rbInvitado.Location = new System.Drawing.Point(7, 44);
            this.rbInvitado.Name = "rbInvitado";
            this.rbInvitado.Size = new System.Drawing.Size(63, 17);
            this.rbInvitado.TabIndex = 1;
            this.rbInvitado.TabStop = true;
            this.rbInvitado.Text = "Invitado";
            this.rbInvitado.UseVisualStyleBackColor = true;
            // 
            // rbDirectivo
            // 
            this.rbDirectivo.AutoSize = true;
            this.rbDirectivo.Location = new System.Drawing.Point(7, 20);
            this.rbDirectivo.Name = "rbDirectivo";
            this.rbDirectivo.Size = new System.Drawing.Size(67, 17);
            this.rbDirectivo.TabIndex = 0;
            this.rbDirectivo.TabStop = true;
            this.rbDirectivo.Text = "Directivo";
            this.rbDirectivo.UseVisualStyleBackColor = true;
            // 
            // rbAdminitrativo
            // 
            this.rbAdminitrativo.AutoSize = true;
            this.rbAdminitrativo.Location = new System.Drawing.Point(7, 44);
            this.rbAdminitrativo.Name = "rbAdminitrativo";
            this.rbAdminitrativo.Size = new System.Drawing.Size(90, 17);
            this.rbAdminitrativo.TabIndex = 1;
            this.rbAdminitrativo.TabStop = true;
            this.rbAdminitrativo.Text = "Administrativo";
            this.rbAdminitrativo.UseVisualStyleBackColor = true;
            // 
            // rbAsistente
            // 
            this.rbAsistente.AutoSize = true;
            this.rbAsistente.Location = new System.Drawing.Point(7, 68);
            this.rbAsistente.Name = "rbAsistente";
            this.rbAsistente.Size = new System.Drawing.Size(68, 17);
            this.rbAsistente.TabIndex = 2;
            this.rbAsistente.TabStop = true;
            this.rbAsistente.Text = "Asistente";
            this.rbAsistente.UseVisualStyleBackColor = true;
            // 
            // btnEdad
            // 
            this.btnEdad.Location = new System.Drawing.Point(307, 313);
            this.btnEdad.Name = "btnEdad";
            this.btnEdad.Size = new System.Drawing.Size(139, 36);
            this.btnEdad.TabIndex = 13;
            this.btnEdad.Text = "Calcular Edad";
            this.btnEdad.UseVisualStyleBackColor = true;
            // 
            // btnBoni
            // 
            this.btnBoni.Location = new System.Drawing.Point(307, 356);
            this.btnBoni.Name = "btnBoni";
            this.btnBoni.Size = new System.Drawing.Size(139, 36);
            this.btnBoni.TabIndex = 14;
            this.btnBoni.Text = "Calcular Bonificacion";
            this.btnBoni.UseVisualStyleBackColor = true;
            this.btnBoni.Click += new System.EventHandler(this.btnBoni_Click);
            // 
            // btnTServ
            // 
            this.btnTServ.Location = new System.Drawing.Point(307, 398);
            this.btnTServ.Name = "btnTServ";
            this.btnTServ.Size = new System.Drawing.Size(139, 36);
            this.btnTServ.TabIndex = 15;
            this.btnTServ.Text = "Calcular Tiempo Servicio";
            this.btnTServ.UseVisualStyleBackColor = true;
            // 
            // lblEdad
            // 
            this.lblEdad.AutoSize = true;
            this.lblEdad.Location = new System.Drawing.Point(315, 43);
            this.lblEdad.Name = "lblEdad";
            this.lblEdad.Size = new System.Drawing.Size(42, 13);
            this.lblEdad.TabIndex = 16;
            this.lblEdad.Text = "lblEdad";
            // 
            // lblBoni
            // 
            this.lblBoni.AutoSize = true;
            this.lblBoni.Location = new System.Drawing.Point(315, 87);
            this.lblBoni.Name = "lblBoni";
            this.lblBoni.Size = new System.Drawing.Size(38, 13);
            this.lblBoni.TabIndex = 17;
            this.lblBoni.Text = "lblBoni";
            // 
            // lblTServ
            // 
            this.lblTServ.AutoSize = true;
            this.lblTServ.Location = new System.Drawing.Point(315, 133);
            this.lblTServ.Name = "lblTServ";
            this.lblTServ.Size = new System.Drawing.Size(46, 13);
            this.lblTServ.TabIndex = 18;
            this.lblTServ.Text = "lblTServ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(458, 462);
            this.Controls.Add(this.lblTServ);
            this.Controls.Add(this.lblBoni);
            this.Controls.Add(this.lblEdad);
            this.Controls.Add(this.btnTServ);
            this.Controls.Add(this.btnBoni);
            this.Controls.Add(this.btnEdad);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.cbColaborador);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cbColaborador;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbInvitado;
        private System.Windows.Forms.RadioButton rbEstable;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton rbAsistente;
        private System.Windows.Forms.RadioButton rbAdminitrativo;
        private System.Windows.Forms.RadioButton rbDirectivo;
        private System.Windows.Forms.Button btnEdad;
        private System.Windows.Forms.Button btnBoni;
        private System.Windows.Forms.Button btnTServ;
        private System.Windows.Forms.Label lblEdad;
        private System.Windows.Forms.Label lblBoni;
        private System.Windows.Forms.Label lblTServ;
    }
}

